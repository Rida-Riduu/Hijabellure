
# Hijabellure — Static Website

A lightweight, responsive storefront for Hijabellure (static HTML/CSS/JS). 
No backend required. Cart and demo checkout use localStorage (client-side only).

## Structure
- `index.html` — Home with hero + bestsellers
- `shop.html` — Product grid with category filters
- `cart.html` — View and update cart
- `checkout.html` — Demo checkout form + order summary
- `success.html` — Order confirmation (localStorage)
- `lookbook.html`, `about.html`, `contact.html`
- `assets/styles.css` — Styles
- `assets/app.js` — Logic (products, cart)

## How to use
1. **Preview locally**: open `index.html` in your browser. (Chrome may block `fetch` of local files; this site doesn't use fetch so it works offline.)
2. **Edit products**: open `assets/app.js` and edit the `products` array (names, prices, tags, images).
3. **Replace images**: drop JPG/PNG files into `assets/images/` and update the paths in `app.js`.
4. **Deploy**:
   - **Netlify** / **Vercel**: drag & drop the folder.
   - **GitHub Pages**: push the folder to a repo and enable Pages (root).
   - **Custom hosting**: upload files to your `/public` or web root.

## Notes
- This is a **demo storefront** (no payments). To accept payments, connect to Shopify/Stripe or a headless backend later.
- Colors/typography are neutral and easy to retheme. Adjust CSS variables in `:root`.
- The code is intentionally simple and framework-free (no React/Vue).

## License
You own the brand and content. Use freely for Hijabellure.
