
/* Simple front-end store functionality (no backend).
 * Products, cart, and fake checkout stored in localStorage.
 */
const products = [
  {id:1, name:"Everyday Chiffon", price:69, tag:"Everyday", img:"assets/images/product_1.svg"},
  {id:2, name:"Luxury Satin", price:99, tag:"Luxury", img:"assets/images/product_2.svg"},
  {id:3, name:"Printed Bloom", price:89, tag:"Printed", img:"assets/images/product_3.svg"},
  {id:4, name:"Textured Crinkle", price:79, tag:"Everyday", img:"assets/images/product_4.svg"},
  {id:5, name:"Modal Classic", price:85, tag:"Essentials", img:"assets/images/product_5.svg"},
  {id:6, name:"Jersey Comfort", price:75, tag:"Essentials", img:"assets/images/product_6.svg"},
  {id:7, name:"Eid Edition", price:119, tag:"Luxury", img:"assets/images/product_7.svg"},
  {id:8, name:"Underscarf Essential", price:35, tag:"Essentials", img:"assets/images/product_8.svg"},
];

const ls = {
  get(k, fallback){ try{ return JSON.parse(localStorage.getItem(k)) ?? fallback }catch(e){ return fallback } },
  set(k, v){ localStorage.setItem(k, JSON.stringify(v)) }
};

function byId(id){ return document.getElementById(id); }

function renderBest(){
  const el = byId('best-grid'); if(!el) return;
  const best = products.slice(0,4);
  el.innerHTML = best.map(card).join('');
}

function renderShop(items=products){
  const el = byId('shop-grid'); if(!el) return;
  el.innerHTML = items.map(card).join('');
}

function card(p){
  return `<article class="card" aria-label="${p.name}">
    <img src="${p.img}" alt="${p.name}">
    <div class="card-body">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px">
        <div>
          <strong>${p.name}</strong><br>
          <span class="badge-chip">${p.tag}</span>
        </div>
        <div class="price">AED ${p.price}</div>
      </div>
      <div style="margin-top:10px; display:flex; gap:8px">
        <button class="btn" onclick="addToCart(${p.id})">Add to cart</button>
        <a class="btn secondary" href="cart.html">View Cart</a>
      </div>
    </div>
  </article>`;
}

function filterCategory(cat){
  if(cat==='all'){ renderShop(products); return; }
  renderShop(products.filter(p=>p.tag===cat));
}

function getCart(){ return ls.get('cart', []); }
function setCart(c){ ls.set('cart', c); updateCartBadge(); }

function addToCart(id){
  const cart = getCart();
  const found = cart.find(x=>x.id===id);
  if(found) found.qty += 1; else cart.push({id, qty:1});
  setCart(cart);
  alert('Added to cart');
}

function removeFromCart(id){
  const cart = getCart().filter(x=>x.id!==id);
  setCart(cart);
  renderCart();
}

function changeQty(id, delta){
  const cart = getCart();
  const item = cart.find(x=>x.id===id);
  if(!item) return;
  item.qty = Math.max(1, item.qty + delta);
  setCart(cart);
  renderCart();
}

function cartItemsDetailed(){
  const cart = getCart();
  return cart.map(ci => ({...ci, product: products.find(p=>p.id===ci.id)}));
}

function money(n){ return `AED ${n.toFixed(2)}`; }

function renderCart(){
  const el = byId('cart-view'); if(!el) return;
  const items = cartItemsDetailed();
  if(items.length === 0){
    el.innerHTML = `<p>Your cart is empty.</p>`;
    return;
  }
  const rows = items.map(it => {
    const subtotal = it.qty * it.product.price;
    return `<div style="display:grid; grid-template-columns:80px 1fr auto; gap:12px; border-bottom:1px solid #eee; padding:10px 0">
      <img src="${it.product.img}" alt="${it.product.name}" style="width:80px; height:80px; object-fit:cover; border-radius:10px; border:1px solid #eee">
      <div>
        <strong>${it.product.name}</strong><br>
        <span class="badge-chip">${it.product.tag}</span>
        <div style="margin-top:8px">
          <button class="btn secondary" onclick="changeQty(${it.id}, -1)">−</button>
          <span style="margin:0 8px">${it.qty}</span>
          <button class="btn secondary" onclick="changeQty(${it.id}, 1)">+</button>
          <button class="btn" style="margin-left:8px" onclick="removeFromCart(${it.id})">Remove</button>
        </div>
      </div>
      <div class="price">${money(subtotal)}</div>
    </div>`;
  }).join('');

  const total = items.reduce((sum, it)=> sum + it.qty * it.product.price, 0);
  el.innerHTML = rows + `<div style="text-align:right; margin-top:10px"><strong>Total: ${money(total)}</strong></div>`;
}

function renderSummary(){
  const el = byId('summary'); if(!el) return;
  const items = cartItemsDetailed();
  if(items.length===0){ el.innerHTML = `<p>No items. <a href="shop.html">Go to shop</a>.</p>`; return; }
  const list = items.map(it => `<div style="display:flex; justify-content:space-between; margin:6px 0">
    <span>${it.product.name} × ${it.qty}</span><span>${money(it.product.price*it.qty)}</span></div>`).join('');
  const total = items.reduce((s,it)=>s+it.qty*it.product.price,0);
  el.innerHTML = list + `<hr><div style="display:flex; justify-content:space-between"><strong>Total</strong><strong>${money(total)}</strong></div>`;
}

function placeOrder(){
  const order = {
    id: 'HB' + Math.floor(Math.random()*1e6),
    at: new Date().toISOString(),
    items: cartItemsDetailed(),
    customer: {
      name: byId('fullName').value,
      address: byId('address').value,
      city: byId('city').value,
      country: byId('country').value,
      email: byId('email').value,
    }
  };
  ls.set('last_order', order);
  ls.set('cart', []);
  location.href = 'success.html';
}

function renderOrder(){
  const el = byId('order-confirm'); if(!el) return;
  const order = ls.get('last_order', null);
  if(!order){ el.innerHTML = '<p>No recent order found.</p>'; return; }
  const items = order.items.map(it=>`<li>${it.product.name} × ${it.qty}</li>`).join('');
  el.innerHTML = `<div class="notice"><strong>Order ${order.id}</strong><br>
    Placed at ${new Date(order.at).toLocaleString()}<br>
    <ul>${items}</ul>
    <div><strong>Ship to:</strong> ${order.customer.name}, ${order.customer.address}, ${order.customer.city}, ${order.customer.country}</div>
  </div>`;
}

function updateCartBadge(){
  const countEl = byId('cart-count'); if(!countEl) return;
  const total = getCart().reduce((s, it)=> s + it.qty, 0);
  countEl.textContent = total;
}

// Contact form demo
function fakeSubmit(form){
  alert('Thanks! Your message has been noted (demo).');
  form.reset();
}

// Footer year
(function(){ const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear(); })();

// Page init
document.addEventListener('DOMContentLoaded', () => {
  renderBest();
  renderShop();
  renderCart();
  renderSummary();
  renderOrder();
  updateCartBadge();
});
